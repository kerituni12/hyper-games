export const environment = {
  production: true,
  interstitial_ad_id : "ca-app-pub-8822167997253741/5926060893",
  banner_ad_id: "ca-app-pub-8822167997253741/3524921934",
  ios_interstitial_ad_id : "ca-app-pub-8822167997253741/5926060893",
  ios_banner_ad_id: "ca-app-pub-8822167997253741/3524921934",
  enableapi: false, // Admin Panel API 
  testing_ad: true,
  app_name: "Hyper Games",
  support_email: "nativecode@demomail.com",
  support_phone: "441541230",
  support_url: "https://yourdomain.com",
  about_app: "Lorem ipsum, dolor sit amet consectetur adipisicing elit. Nulla quaerat asperiores fugit eum deserunt voluptate nostrum saepe numquam aperiam quae aspernatur voluptatem, necessitatibus voluptatibus perferendis nam suscipit, excepturi perspiciatis accusamus.",
  app_version:"v3.0.0"
};
